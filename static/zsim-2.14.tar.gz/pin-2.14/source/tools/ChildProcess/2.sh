echo $var
