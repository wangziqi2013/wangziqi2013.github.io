export var=SUCCESS
./2.sh
