#!/bin/sh
/bin/uname -s >$1
